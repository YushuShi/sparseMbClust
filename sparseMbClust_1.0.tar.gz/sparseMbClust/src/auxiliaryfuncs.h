#ifndef auxiliaryfuncs_h
#define auxiliaryfuncs_h

#include<Rcpp.h>
using namespace Rcpp ;
NumericMatrix subsetbyrow(const NumericMatrix X, const LogicalVector T);
NumericMatrix subsetbycol(const NumericMatrix X, const LogicalVector T);
NumericVector rowsum( const NumericMatrix X );
IntegerVector choose2 (const int size);
NumericMatrix cbindv(const NumericMatrix a, const NumericVector b);
NumericVector addconst(const NumericVector X, double y);
NumericMatrix subsetcolind(const NumericMatrix X, const IntegerVector Indicator);
double min(double a, double b);
double nugen(const double nu, const int ngrp, const int npts,const double a, const double b);
#endif /* auxiliaryfuncs_h */
