#ifndef MFMDM_h
#define MFMDM_h

#include <Rcpp.h>

using namespace Rcpp;
List MFMDM(NumericMatrix X, IntegerVector c, IntegerVector gamma, double alpha1, double alpha2, double nu, double w, int totaliter, double beta1, double beta2, double lambda, double pargamma);
#endif /* MFMDM_h */
