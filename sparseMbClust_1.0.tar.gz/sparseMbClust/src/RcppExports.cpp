#include <Rcpp.h>
#include "dpdm.h"
#include "MFMDM.h"
using namespace Rcpp;

RcppExport SEXP expt1(SEXP XSEXP, SEXP cSEXP, SEXP gammaSEXP, SEXP alpha1SEXP, SEXP alpha2SEXP, SEXP nuSEXP, SEXP wSEXP, SEXP totaliterSEXP,SEXP aSEXP, SEXP bSEXP, SEXP beta1SEXP, SEXP beta2SEXP) {

    Rcpp::RObject __result;
    Rcpp::RNGScope __rngScope;

    Rcpp::traits::input_parameter< NumericMatrix >::type X(XSEXP);
    Rcpp::traits::input_parameter< IntegerVector >::type c(cSEXP);
    Rcpp::traits::input_parameter< IntegerVector >::type gamma(gammaSEXP);
    Rcpp::traits::input_parameter< double >::type alpha1(alpha1SEXP);
    Rcpp::traits::input_parameter< double >::type alpha2(alpha2SEXP);
    Rcpp::traits::input_parameter< double >::type nu(nuSEXP);
    Rcpp::traits::input_parameter< double >::type w(wSEXP);
    Rcpp::traits::input_parameter< int >::type totaliter(totaliterSEXP);
    Rcpp::traits::input_parameter< double >::type a(aSEXP);
    Rcpp::traits::input_parameter< double >::type b(bSEXP);
    Rcpp::traits::input_parameter< double >::type beta1(beta1SEXP);
    Rcpp::traits::input_parameter< double >::type beta2(beta2SEXP);   
        __result = Rcpp::wrap(dpdm(X, c, gamma, alpha1, alpha2, nu, w, totaliter, a, b, beta1, beta2));
    return __result;
}

RcppExport SEXP expt2(SEXP XSEXP, SEXP cSEXP, SEXP gammaSEXP, SEXP alpha1SEXP, SEXP alpha2SEXP, SEXP nuSEXP, SEXP wSEXP, SEXP totaliterSEXP, SEXP beta1SEXP, SEXP beta2SEXP,
SEXP pargammaSEXP, SEXP lambdaSEXP) {

    Rcpp::RObject __result;
    Rcpp::RNGScope __rngScope;

    Rcpp::traits::input_parameter< NumericMatrix >::type X(XSEXP);
    Rcpp::traits::input_parameter< IntegerVector >::type c(cSEXP);
    Rcpp::traits::input_parameter< IntegerVector >::type gamma(gammaSEXP);
    Rcpp::traits::input_parameter< double >::type alpha1(alpha1SEXP);
    Rcpp::traits::input_parameter< double >::type alpha2(alpha2SEXP);
    Rcpp::traits::input_parameter< double >::type nu(nuSEXP);
    Rcpp::traits::input_parameter< double >::type w(wSEXP);
    Rcpp::traits::input_parameter< int >::type totaliter(totaliterSEXP);
    Rcpp::traits::input_parameter< double >::type beta1(beta1SEXP);
    Rcpp::traits::input_parameter< double >::type beta2(beta2SEXP);
    Rcpp::traits::input_parameter< double >::type pargamma(pargammaSEXP);
    Rcpp::traits::input_parameter< double >::type lambda(lambdaSEXP);       
        __result = Rcpp::wrap(MFMDM(X, c, gamma, alpha1, alpha2, nu, w, totaliter, beta1, beta2, pargamma, lambda));
    return __result;
}

