#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>

using namespace Rcpp ;

NumericMatrix subsetbyrow(const NumericMatrix X, const LogicalVector T){
    NumericMatrix Y(sum(T),X.ncol());
    IntegerVector Indicator=seq_along(T);
    Indicator=Indicator[T];
    for(int i=0; i<sum(T); i++){
        Y(i,_)=X(Indicator[i]-1,_);
    }
    return Y;
}

NumericMatrix subsetbycol(const NumericMatrix X, const LogicalVector T){
    NumericMatrix Y(X.nrow(),sum(T));
    IntegerVector Indicator=seq_along(T);
   Indicator=Indicator[T];
    for(int i=0; i<sum(T); i++){
        Y(_,i)=X(_,Indicator[i]-1);
    }
    return Y;
}

NumericVector rowsum( const NumericMatrix X ) {
    int nrow = X.nrow();
    NumericVector out = no_init(nrow);
    
    for( int i=0; i < nrow; i++ ) {
        NumericVector tmp = X(i, _);
        out[i] = sum( tmp );
    }
    return out;
}

IntegerVector choose2 (const int size)
{
    int first = floor(runif(1)[0] * size);
    int second = floor(runif(1)[0] * (size - 1.0));
    if (second >= first)
    {
      second+=1;
    }
    IntegerVector x(2);
    x[0]=first;
    x[1]=second;
    return x;
}

NumericMatrix cbindv(const NumericMatrix a, const NumericVector b) {
    int acoln = a.ncol();
    NumericMatrix out = no_init_matrix(a.nrow(), acoln + 1);
    for (int j = 0; j < acoln + 1; j++) {
        if (j < acoln) {
            out(_, j) = a(_, j);
        } else {
            out(_, j) = b;
        }
    }
    return out;
}

NumericVector addconst(const NumericVector X, double y){
    NumericVector Xclone(X.size());
    for(int i=0; i<X.size();i++){
        Xclone[i]+=X[i]+y;
    }
    return Xclone;
}

NumericMatrix subsetcolind(const NumericMatrix X, const IntegerVector Indicator){
    NumericMatrix out(X.nrow(),Indicator.size());
    for(int i=0; i<Indicator.size();i++){
        out(_,i)=X(_,Indicator[i]-1);
    }
    return out;
}

double min(double a, double b){
    if(a>b){return b;}
    else{return a;}
}

double nugen(const double nu, const int ngrp, const int npts,const double a, const double b)
{
    double eta=rbeta(1,nu + 1.0, double(npts))[0];
    double pi_eta = (a + double(ngrp) - 1.0) / (double(npts)*(b - log(eta)) + (a + double(ngrp) - 1.0));
    if(rbinom(1,1.0, pi_eta)[0] == 1.0){
        return R::rgamma(a + double(ngrp),1.0/(b - log(eta)));
    }else{
        return R::rgamma(a + double(ngrp)-1.0,1.0/(b - log(eta)));
    }
}
