#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>
#include "auxiliaryfuncs.h"
using namespace Rcpp ;

double likelihoodratio(NumericMatrix X, const IntegerVector c, const IntegerVector gamma_old, const IntegerVector gamma_new, double alpha1, double alpha2, double beta1, double beta2){
    IntegerVector aux1(gamma_old.size(),1);
    IntegerVector rev_gamma_old=aux1-gamma_old;
    IntegerVector rev_gamma_new=aux1-gamma_new;

    NumericMatrix interesting_old=subsetbyrow(X,gamma_old>0);
    NumericMatrix notinteresting_old=subsetbyrow(X,rev_gamma_old>0);
    NumericVector notintrow_old=rowsum(notinteresting_old);
    
    NumericMatrix interesting_new=subsetbyrow(X,gamma_new>0);
    NumericMatrix notinteresting_new=subsetbyrow(X,rev_gamma_new>0);
    NumericVector notintrow_new=rowsum(notinteresting_new);
    
    double lognotinteresting_old=lgamma(sum(rev_gamma_old)*alpha1)-sum(rev_gamma_old)*lgamma(alpha1);
    double lognotinteresting_new=lgamma(sum(rev_gamma_new)*alpha1)-sum(rev_gamma_new)*lgamma(alpha1);

    for(int j=0; j<notinteresting_old.nrow();j++){
        lognotinteresting_old+=lgamma(notintrow_old(j)+alpha1);
    }
    for(int j=0; j<notinteresting_new.nrow();j++){
        lognotinteresting_new+=lgamma(notintrow_new(j)+alpha1);
    }
    lognotinteresting_old-=lgamma(sum(notintrow_old)+notinteresting_old.nrow()*alpha1);
    lognotinteresting_new-=lgamma(sum(notintrow_new)+notinteresting_new.nrow()*alpha1);

    IntegerVector uniquec=unique(c);
    double loginteresting_old=uniquec.size()*(lgamma(sum(gamma_old)*alpha2)-sum(gamma_old)*lgamma(alpha2));
    double loginteresting_new=uniquec.size()*(lgamma(sum(gamma_new)*alpha2)-sum(gamma_new)*lgamma(alpha2));
    for(int k=0; k<uniquec.size();k++){
        NumericMatrix subset_old=subsetbycol(interesting_old,(c==uniquec(k)));
        NumericMatrix subset_new=subsetbycol(interesting_new,(c==uniquec(k)));
        NumericMatrix notsubset_old=subsetbycol(notinteresting_old,(c==uniquec(k)));
        NumericMatrix notsubset_new=subsetbycol(notinteresting_new,(c==uniquec(k)));
        NumericVector row_old=rowsum(subset_old);
        NumericVector row_new=rowsum(subset_new);
        loginteresting_old+=lgamma(beta1+sum(notsubset_old))+lgamma(beta2+sum(subset_old))-lgamma(beta1+beta2+sum(notsubset_old)+sum(subset_old));
        loginteresting_new+=lgamma(beta1+sum(notsubset_new))+lgamma(beta2+sum(subset_new))-lgamma(beta1+beta2+sum(notsubset_new)+sum(subset_new));
        for(int i=0; i<subset_old.nrow();i++){
            loginteresting_old+=lgamma(row_old(i)+alpha2);
        }
        for(int i=0; i<subset_new.nrow();i++){
            loginteresting_new+=lgamma(row_new(i)+alpha2);
        }
        loginteresting_old-=lgamma(sum(row_old)+subset_old.nrow()*alpha2);
        loginteresting_new-=lgamma(sum(row_new)+subset_new.nrow()*alpha2);
    }
    double plan_old=loginteresting_old+lognotinteresting_old;
    double plan_new=loginteresting_new+lognotinteresting_new;
    double likelihoodratio=plan_new-plan_old;
    return likelihoodratio;
}


