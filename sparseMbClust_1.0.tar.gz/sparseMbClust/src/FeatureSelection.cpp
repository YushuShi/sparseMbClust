#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>

#include "auxiliaryfuncs.h"
#include "likelihoodratio.h"
using namespace Rcpp ;

void FeatureSelection(NumericMatrix X, IntegerVector c, IntegerVector gamma, double alpha1, double alpha2, double w, double beta1, double beta2){
	//gamma0 the locations where gamma is 0
	//gamma1 the locations where gamma is 1
    IntegerVector gamma0=seq_along(gamma);
    gamma0=gamma0[gamma==0];
    IntegerVector gamma1=seq_along(gamma);
    gamma1=gamma1[gamma==1];
    int t=100;
    double ratio1=0.0;
    int int1=0;
    int int2=0;
    int gamma0_choose=0;
    int gamma1_choose=0;
    for(int i=0; i<t; i++){
		// dice 1 decides switch or swap
        int dice1=Rf_rbinom(1,0.5);
        IntegerVector gamma_new(clone(gamma));
        if(dice1==1){
            int1=floor(runif(1)[0]*gamma.size());
            int2=gamma[int1];
			//gamma_new is the swapped gamma
            gamma_new[int1]=1-int2;
            if(int2==1){
				// if the original is 1 and swap from 1 to 0
                ratio1=log(1.0-w)-log(w);
            }else{
                ratio1=log(w)-log(1.0-w);
            }
        }else{
            if((gamma0.size()>0)&(gamma1.size()>0)){
                gamma0_choose=gamma0[floor(runif(1)[0]*gamma0.size())]-1;
                gamma1_choose=gamma1[floor(runif(1)[0]*gamma1.size())]-1;
                gamma_new[gamma0_choose]=1;
                gamma_new[gamma1_choose]=0;
            }
        }
        
        double lr=likelihoodratio(X,c,gamma,gamma_new,alpha1,alpha2,beta1,beta2);
        int dice2=Rf_rbinom(1,min(1.0,exp(lr+ratio1)));
        if(dice2==1){
         if(dice1==1){
           gamma[int1]=1-int2;
         }else{
           gamma[gamma0_choose]=1;
           gamma[gamma1_choose]=0;
         }
    }
  }
}

