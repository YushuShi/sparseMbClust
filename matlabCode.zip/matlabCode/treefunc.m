function [crec,gammarec]=treefunc(w, a, b,totaliter,alpha)
global c gamma;
nu=1.0;
crec=zeros(totaliter,length(c));
gammarec=zeros(totaliter,length(gamma));
for iter=1:totaliter
    treeprune(alpha,w);
	treeassign(nu,alpha);
    uc=unique(c);
      if mod(iter,50)==0
      disp(iter)
      fprintf('Number of features selected %d .\n',sum(gamma));
  	fprintf('Observation Assignment .\n');
      disp(c)
      fprintf('Number of Unique Cluster %d .\n',length(uc));
      end

	nu=nugen(nu,length(uc),length(c),a,b);
	crec(iter,:)=c;
	gammarec(iter,:)=gamma;

end
end