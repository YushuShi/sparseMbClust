function realdata(par)

tableall=zeros(173,2976,29);
global tree;
load phylotreestructure.mat
tree=treestructure;

for i = 1:29
 load(['data/children'  num2str(i) '.mat']);
tableall(:,:,i)=tablesub;
end
global table;
table=tableall;
global c;
c=repelem(1,size(table,3));
global gamma;
gamma=repelem(1,size(table,1));

w=0.5;
a=1;
b=1;
totaliter=20000;
alpha=1;

table=table./76.62333;
[crec,gammarec]=treefunc(w, a, b,totaliter,alpha);

save('realdata.mat','crec','gammarec');

end
