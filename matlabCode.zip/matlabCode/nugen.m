function result=nugen(nu,ngrp,npts,a,b)
eta=betarnd(1+nu,npts);
pi_eta = (a +ngrp- 1.0) / (npts*(b - log(eta)) + (a + ngrp - 1.0));
    if binornd(1,pi_eta)
        result=gamrnd(a + ngrp,1.0/(b - log(eta)));
    else
        result=gamrnd(a + ngrp-1.0,1.0/(b - log(eta)));
    end
end