PerformClustering<-function(otutable, ClusteringMethod,c=NULL, gamma=NULL, alpha1=1, alpha2=1, nu=1, w=0.5, 
                       beta1=1, beta2=1, a=1, b=1, pargamma=1,lambda=1,totaliter=20000,burnin=10000, thin=50) 
{   
  # if(is.null(rownames(otutable))|is.null(rownames(otutable))){
  #   stop("Sorry! OTU identification number and observation names must be given!")	
  # }
  if(is.null(c)){
    c<-rep(1,ncol(otutable))
  }
  if(is.null(gamma)){
    gamma<-rep(1,nrow(otutable))
  }
  if(ClusteringMethod=="DP"){
    z<-.Call('expt1', PACKAGE = 'BayesianMicrobiome',
             otutable, c, gamma, alpha1, alpha2, nu, w, totaliter, a, b, beta1, beta2)
  }else{
    z<-.Call('expt2', PACKAGE = 'BayesianMicrobiome',
             otutable, c, gamma, alpha1, alpha2, nu, w, totaliter, beta1, beta2,pargamma,lambda)
  }

z$crec<-z$crec[seq(from=burnin+thin,to=totaliter,by=thin),]
z$gammarec<-z$gammarec[seq(from=burnin+thin,to=totaliter,by=thin),]
z
}
