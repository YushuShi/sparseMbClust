#ifndef MFM_h
#define MFM_h

double logPoissonK(int k, double lambda);

double logV(double pargamma,int n,int t, double lambda);
#endif /* MFM_h */
