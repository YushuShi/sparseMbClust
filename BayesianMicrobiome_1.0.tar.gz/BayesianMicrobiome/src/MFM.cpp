#include <algorithm>
#include <math.h>


double logPoissonK(int k, double lambda){
	return (double(k)-1.0)*log(lambda)-lambda-lgamma(double(k));
}

double logV(double pargamma,int n,int t, double lambda){
	double tolerance=pow(10.0,-12.0);
	double temp1=0.0;
	double temp2=0.0;
	double p=0.0;
	int upperlimit=100;
	for(int k=t; k<upperlimit; k++){
		if((abs(temp1-temp2) > tolerance) || (p < (1.0-tolerance))){
			temp1=temp2;
			temp2+=exp(lgamma(k+1.0)-lgamma(k-t+1.0)-lgamma(k*pargamma+n)+lgamma(k*pargamma)+logPoissonK(k,lambda));
			p+=exp(logPoissonK(k,lambda));
		}
	}
	return log(temp2);
}
