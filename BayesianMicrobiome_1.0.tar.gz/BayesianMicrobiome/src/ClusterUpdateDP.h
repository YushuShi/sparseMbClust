#ifndef ClusterUpdateDP_h
#define ClusterUpdateDP_h

#include<Rcpp.h>
using namespace Rcpp ;
void ClusterUpdateDP(NumericMatrix X, IntegerVector c,  const IntegerVector gamma, double alpha1, double alpha2, double nu, double beta1, double beta2);
#endif /* ClusterUpdateDP_h */
