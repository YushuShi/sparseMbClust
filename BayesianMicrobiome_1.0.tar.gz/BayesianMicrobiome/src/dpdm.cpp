#include <iostream>
#include <vector>
#include <Rmath.h>
#include <R.h>
#include <algorithm>
#include <math.h>
#include <Rcpp.h>

using namespace Rcpp;
#include "auxiliaryfuncs.h"
#include "FeatureSelection.h"
#include "ClusterUpdateDP.h"

// [[Rcpp::export]]
List dpdm(NumericMatrix X, IntegerVector c, IntegerVector gamma, double alpha1, double alpha2, double nu, double w, int totaliter,
          double a, double b, double beta1, double beta2){
    NumericMatrix crec(totaliter,c.size());
    NumericMatrix gammarec(totaliter,gamma.size());
    for(int iter=0; iter<totaliter; iter++){
		
		//X is the OTU matrix
		//c is the cluster indicator
		//gamma is the feature selection indicator
		//alpha1 alpha2 are for Dirichlet
		//w the proportion of sequences that are discriminating
		//beta1 beta2 parameters for beta
		
		
		//update gamma
        FeatureSelection(X,c,gamma,alpha1,alpha2,w, beta1, beta2);
		//update c
        ClusterUpdateDP(X,c,gamma,alpha1,alpha2,nu, beta1, beta2);
        IntegerVector uc=unique(c);
        nu=nugen(nu,uc.size(),X.ncol(),a,b);
        crec(iter,_)=c;
      if((iter+1)%100==0){
		  Rcout<<"Iteration Number	"<<iter+1<<std::endl;
          Rcout<<"Number of Unique Clusters "<<uc.size()<<std::endl;
          Rcout<<"Number of Selected Features "<<sum(gamma)<<std::endl;
          Rcout<<std::endl;
      }

        gammarec(iter,_)=gamma;
    }
    return List::create(Named("crec")=crec,Named("gammarec")=gammarec);
}
